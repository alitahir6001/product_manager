import {Link} from '@reach/router';
const Main = ({products}) => {

        return (
        // <>
        
        products ?
            <table className="table table-hover col-6 mx-auto">
                <thead>
                    <tr>
                        <th>Products</th>
                        <th>Price</th>
                        <th>Description</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        products.map((j, i) => { // This is being pulled from the api './.../products route, which maps out all the current products in the data base.
                            return <tr key={i}>
                                    <td>{j.title}</td>
                                    <td>{j.price}</td>
                                    <td>{j.description}</td>
                                    <td>
                                        <Link to={`/edit/${j._id}`}><button type="button" class="btn btn-warning">Edit</button></Link> 
                                        <Link to={`/show/${j._id}`}><button type="button" class="btn btn-info">View Product</button></Link>
                                    </td>
                            </tr>
                        })
                    }
                </tbody>
            </table> :
                <h2>Loading....</h2>

        // </>
    )

}


export default Main;